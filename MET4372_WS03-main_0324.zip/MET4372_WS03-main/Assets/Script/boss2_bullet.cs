using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class boss2_bullet : MonoBehaviour
{
    public int atk;
    public GameObject hitVFX;

    private void OnTriggerEnter2D(Collider2D collision)
    {            
        PlayerController PC = collision.gameObject.GetComponent<PlayerController>();
        if (collision.gameObject.CompareTag("Player") && !PC.isDefending)
        {
            PC.HP -= atk;
            Instantiate(hitVFX, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
        else if (collision.gameObject.CompareTag("Player") && PC.isDefending)
        {
            Destroy(gameObject);
        }


        if (collision.gameObject.name == "BulletRemover")
        {
            Destroy(gameObject);
        }
    }
}
